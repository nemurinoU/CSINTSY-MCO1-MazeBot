# CSINTSY MCO1 MazeBot
 Major Course Output 1: MazeBot
